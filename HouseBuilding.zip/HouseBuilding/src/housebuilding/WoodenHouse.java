/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package housebuilding;

/**
 *
 * @author Hana
 */
public class WoodenHouse extends HouseBuilding {
    public void buildPillars(){
        System.out.println("Placing of the wooden pillars in order to build house framework.");
    }
    public void buildWalls() {
        System.out.println("Building wooden walls.");
    }
    public void buildRoof() {
        System.out.println ("Building wooden roof.");
    }
    public void buildEntranceDoor(){
        System.out.println("Installation of the wooden entrance door.");
    }
    
}
