/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package housebuilding;

/**
 *
 * @author Acer
 */


/**
 *
 * @author Hana
 */
public class GlassHouse extends HouseBuilding {
     public void buildPillars(){
        System.out.println("Placing of the metal pillars in order to build house framework.");
    }
    public void buildWalls() {
        System.out.println("Building glass walls.");
    }
    public void buildRoof() {
        System.out.println ("Building glass roof.");
    }
    public void buildEntranceDoor(){
        System.out.println("Installation of the glass entrance door.");
    }
}


