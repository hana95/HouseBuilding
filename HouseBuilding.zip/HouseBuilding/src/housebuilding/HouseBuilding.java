/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package housebuilding;

/**
 *
 * @author Hana
 */
public abstract class HouseBuilding {
    final void buildHouse(){
        buildFoundation();
        buildPillars();
        buildWalls();
        buildRoof();
        buildEntranceDoor();
        buildWindows();
       
    }

abstract void buildPillars();
abstract void buildWalls();
abstract void buildRoof();
abstract void buildEntranceDoor();


void buildFoundation(){
System.out.println("Building the house foundation from mixture of water, gravel, sand, cement and nets.");
}

void buildWindows() {
System.out.println("Installation of the glass windows.\n \n");
}
}