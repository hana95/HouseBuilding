/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package housebuilding;

/**
 *
 * @author Hana
 */
public class HouseBuildingTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       WoodenHouse woodenHouse = new WoodenHouse();
       GlassHouse glassHouse = new GlassHouse();
       
       System.out.println ("¨¨Building wooden house¨¨¨\n");
       woodenHouse.buildHouse();
       
       System.out.println ("¨¨Building Glass House¨¨\n");
       glassHouse.buildHouse();
            
    }
    
}













